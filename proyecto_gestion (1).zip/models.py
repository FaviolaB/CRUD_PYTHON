"""
models.py
---------
CAPA MODELO (la "M" de MVC).

Reglas de esta capa:
    - Define qué ES un Cliente y qué ES un Estudiante, y las reglas que
      un dato válido debe cumplir.
    - Los objetos se defienden solos: si un dato está mal, el objeto
      NO llega a existir (el constructor lanza ValueError).
    - Nunca lee archivos, nunca usa input() ni print(). No sabe que
      existe una consola ni un archivo JSON.

Inventario de POO en este archivo:
    - Atributos de clase ("estáticos"): CAMPOS, OBLIGATORIOS, total_creados...
    - Atributos privados: __id, __nombre, __email... (name mangling de Python)
    - Propiedades: de lectura/escritura (nombre), de solo lectura (id)
      y calculadas (nombre_completo, promedio, estado).
    - @classmethod: desde_diccionario(), fábricas de objetos.
    - @staticmethod: limpiar(), es_email_valido(), es_telefono_valido()...
"""


import math
import re

# ============================================================
# REGLAS DE VALIDACIÓN (una sola fuente de verdad para ambos modelos)
# ============================================================
# Letras de cualquier idioma (incluye tildes y ñ), sin dígitos ni "_".
# Se permiten espacios, guion y apóstrofe SOLO entre palabras (O'Brien, Ana-María).
_PATRON_TEXTO = re.compile(r"^[^\W\d_]+(?:[ '\-][^\W\d_]+)*$")
_PATRON_EMAIL = re.compile(
    r"^[A-Za-z0-9._%+\-]+@"                      # usuario
    r"(?:[A-Za-z0-9](?:[A-Za-z0-9\-]*[A-Za-z0-9])?\.)+"   # subdominios
    r"[A-Za-z]{2,}$"                              # extensión (.com, .ec ...)
)
_PATRON_CARNET = re.compile(r"^[A-Z0-9]+(?:-[A-Z0-9]+)*$")
_PATRON_MATERIA = re.compile(r"^[\w]+(?:[ \-.][\w]+)*$")

LIMITES = {
    "nombre": (2, 50),
    "apellido": (2, 50),
    "email": (6, 254),
    "ciudad": (2, 50),
    "direccion": (5, 120),
    "carnet": (4, 15),
    "materia": (2, 50),
}
TELEFONO_DIGITOS = 10


def _en_rango(texto, campo):
    minimo, maximo = LIMITES[campo]
    return minimo <= len(texto) <= maximo


def _normalizar_espacios(texto):
    """'  ana    maría ' -> 'ana maría' (colapsa espacios repetidos)."""
    return " ".join(str(texto).split())


def _validar_persona(valor, campo, etiqueta):
    """Valida nombre/apellido: obligatorio, solo letras, largo 2-50."""
    valor = _normalizar_espacios(valor)
    minimo, maximo = LIMITES[campo]
    if not valor:
        raise ValueError(f"El {etiqueta} es obligatorio")
    if not _en_rango(valor, campo):
        raise ValueError(f"El {etiqueta} debe tener entre {minimo} y {maximo} caracteres")
    if not _PATRON_TEXTO.match(valor):
        raise ValueError(
            f"El {etiqueta} solo puede tener letras, espacios, guion o apóstrofe "
            f"(sin números ni símbolos)"
        )
    return valor.title()


def _validar_email(valor):
    """Valida formato y largo del email. Devuelve el email en minúsculas."""
    valor = str(valor).strip()
    usuario = valor.split("@")[0]
    if (not _en_rango(valor, "email") or len(usuario) > 64 or ".." in valor
            or usuario.startswith(".") or usuario.endswith(".")
            or not _PATRON_EMAIL.match(valor)):
        raise ValueError(f"Email inválido: '{valor}'")
    return valor.lower()


class Cliente:
    """MODELO: un cliente válido. Si los datos están mal, el objeto no se crea."""

    # ===== ATRIBUTOS DE CLASE (estáticos): existen una sola vez =====
    CAMPOS = ("nombre", "apellido", "email", "telefono", "ciudad", "direccion")
    OBLIGATORIOS = ("nombre", "apellido", "email")
    total_creados = 0

    def __init__(self, id_cliente, nombre, apellido, email,
                 telefono="", ciudad="", direccion=""):
        self.__id = id_cliente        # privado y sin setter: no se puede cambiar
        # Asignamos por las PROPIEDADES para que la validación corra también al crear
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.telefono = telefono
        self.ciudad = ciudad
        self.direccion = direccion
        Cliente.total_creados += 1    # el contador vive en la CLASE, no en el objeto

    # ===== MÉTODOS ESTÁTICOS: reglas que no dependen de ningún cliente =====
    @staticmethod
    def limpiar(texto):
        return str(texto).strip()

    @staticmethod
    def es_email_valido(texto):
        try:
            _validar_email(texto)
            return True
        except ValueError:
            return False

    @staticmethod
    def es_telefono_valido(texto):
        # Válido si está vacío (es opcional) o si son exactamente 10 dígitos 0-9.
        # isascii() descarta dígitos de otros alfabetos o superíndices ('²', '١'),
        # que isdigit() daría por buenos.
        texto = str(texto).strip()
        return texto == "" or (
            texto.isascii() and texto.isdigit() and len(texto) == TELEFONO_DIGITOS
        )

    # ===== PROPIEDADES =====
    @property
    def id(self):
        # SOLO LECTURA: no tiene setter, así que cliente.id = 5 lanza AttributeError
        return self.__id

    @property
    def nombre(self):
        return self.__nombre

    @nombre.setter
    def nombre(self, valor):
        self.__nombre = _validar_persona(valor, "nombre", "nombre")

    @property
    def apellido(self):
        return self.__apellido

    @apellido.setter
    def apellido(self, valor):
        self.__apellido = _validar_persona(valor, "apellido", "apellido")

    @property
    def email(self):
        return self.__email

    @email.setter
    def email(self, valor):
        self.__email = _validar_email(valor)

    @property
    def telefono(self):
        return self.__telefono

    @telefono.setter
    def telefono(self, valor):
        valor = Cliente.limpiar(valor)
        if not Cliente.es_telefono_valido(valor):
            raise ValueError(
                f"El teléfono debe estar vacío o tener exactamente {TELEFONO_DIGITOS} "
                f"dígitos (solo números 0-9, sin espacios ni guiones)"
            )
        self.__telefono = valor

    @property
    def ciudad(self):
        return self.__ciudad

    @ciudad.setter
    def ciudad(self, valor):
        # Opcional: vacío se acepta; si trae algo, debe parecer un nombre de ciudad
        valor = _normalizar_espacios(valor)
        if valor:
            minimo, maximo = LIMITES["ciudad"]
            if not _en_rango(valor, "ciudad"):
                raise ValueError(f"La ciudad debe tener entre {minimo} y {maximo} caracteres")
            if not _PATRON_TEXTO.match(valor):
                raise ValueError("La ciudad solo puede tener letras, espacios, guion o apóstrofe")
        self.__ciudad = valor.title()

    @property
    def direccion(self):
        return self.__direccion

    @direccion.setter
    def direccion(self, valor):
        # Opcional y de formato libre (lleva números y símbolos), pero con límites
        valor = _normalizar_espacios(valor)
        if valor:
            minimo, maximo = LIMITES["direccion"]
            if not _en_rango(valor, "direccion"):
                raise ValueError(f"La dirección debe tener entre {minimo} y {maximo} caracteres")
        self.__direccion = valor

    # PROPIEDADES CALCULADAS: no guardan nada, se calculan al leerlas
    @property
    def nombre_completo(self):
        return f"{self.__nombre} {self.__apellido}"

    @property
    def iniciales(self):
        return f"{self.__nombre[0]}.{self.__apellido[0]}.".upper()

    @property
    def dominio_email(self):
        return self.__email.split("@")[1]

    # ===== MÉTODOS DE INSTANCIA: necesitan los datos de ESTE cliente =====
    def a_diccionario(self):
        return {
            "id": self.__id,
            "nombre": self.__nombre,
            "apellido": self.__apellido,
            "email": self.__email,
            "telefono": self.__telefono,
            "ciudad": self.__ciudad,
            "direccion": self.__direccion,
        }

    def __str__(self):
        return f"[{self.__id}] {self.nombre_completo} - {self.__email}"

    # ===== MÉTODOS DE CLASE =====
    @classmethod
    def validar_campo(cls, campo, valor):
        """Valida UN campo sin crear el objeto completo. Lanza ValueError si está mal.
        Reutiliza el setter del campo, así la regla vive en un solo lugar."""
        if campo not in cls.CAMPOS:
            raise ValueError(f"Campo no válido: {campo}")
        setattr(object.__new__(cls), campo, valor)

    @classmethod
    def desde_diccionario(cls, datos):
        # cls es la clase: si mañana existe ClienteVIP(Cliente),
        # ClienteVIP.desde_diccionario(d) devolverá un ClienteVIP.
        return cls(
            datos["id"],
            datos["nombre"],
            datos["apellido"],
            datos["email"],
            datos.get("telefono", ""),
            datos.get("ciudad", ""),
            datos.get("direccion", ""),
        )

    @classmethod
    def resumen(cls):
        return f"Se han creado {cls.total_creados} clientes en esta ejecución"


class Estudiante:
    """MODELO: un estudiante con sus materias (set) y sus notas (dict de listas)."""

    CAMPOS = ("nombre", "apellido", "email", "carnet")
    OBLIGATORIOS = ("nombre", "apellido", "email", "carnet")
    NOTA_MINIMA = 0
    NOTA_MAXIMA = 20
    NOTA_APROBACION = 14
    total_creados = 0

    def __init__(self, id_estudiante, nombre, apellido, email, carnet,
                 notas=None, materias=None):
        self.__id = id_estudiante
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.carnet = carnet
        self.__notas = dict(notas) if notas else {}              # DICCIONARIO de LISTAS
        self.__materias = set(materias) if materias else set()   # CONJUNTO
        Estudiante.total_creados += 1

    # ===== ESTÁTICOS =====
    @staticmethod
    def limpiar(texto):
        return str(texto).strip()

    @staticmethod
    def es_nota_valida(nota):
        # No usa self ni cls: es una regla suelta, por eso es estático.
        # - bool se excluye: en Python True es un int (True == 1) y pasaría como nota.
        # - isfinite descarta nan e inf.
        return (
            isinstance(nota, (int, float))
            and not isinstance(nota, bool)
            and math.isfinite(nota)
            and Estudiante.NOTA_MINIMA <= nota <= Estudiante.NOTA_MAXIMA
        )

    @staticmethod
    def es_carnet_valido(texto):
        texto = Estudiante.limpiar(texto).upper()
        return _en_rango(texto, "carnet") and bool(_PATRON_CARNET.match(texto))

    @staticmethod
    def es_materia_valida(texto):
        texto = _normalizar_espacios(texto)
        return (
            _en_rango(texto, "materia")
            and bool(_PATRON_MATERIA.match(texto))
            and any(c.isalpha() for c in texto)      # no vale solo números ("123")
        )

    # ===== PROPIEDADES =====
    @property
    def id(self):
        return self.__id

    @property
    def nombre(self):
        return self.__nombre

    @nombre.setter
    def nombre(self, valor):
        self.__nombre = _validar_persona(valor, "nombre", "nombre")

    @property
    def apellido(self):
        return self.__apellido

    @apellido.setter
    def apellido(self, valor):
        self.__apellido = _validar_persona(valor, "apellido", "apellido")

    @property
    def email(self):
        return self.__email

    @email.setter
    def email(self, valor):
        self.__email = _validar_email(valor)

    @property
    def carnet(self):
        return self.__carnet

    @carnet.setter
    def carnet(self, valor):
        valor = Estudiante.limpiar(valor).upper()
        minimo, maximo = LIMITES["carnet"]
        if not valor:
            raise ValueError("El carnet es obligatorio")
        if not Estudiante.es_carnet_valido(valor):
            raise ValueError(
                f"El carnet debe tener entre {minimo} y {maximo} caracteres: "
                f"solo letras, números y guiones (sin espacios ni símbolos)"
            )
        self.__carnet = valor

    @property
    def materias(self):
        # Devolvemos una COPIA: así nadie modifica el conjunto interno desde afuera
        return set(self.__materias)

    @property
    def nombre_completo(self):
        return f"{self.__nombre} {self.__apellido}"

    @property
    def promedio(self):
        # CALCULADA: recorre el diccionario de listas cada vez que se lee
        todas = []
        for lista_notas in self.__notas.values():
            todas.extend(lista_notas)
        return round(sum(todas) / len(todas), 2) if todas else 0

    @property
    def estado(self):
        # CALCULADA: depende únicamente del promedio, no guarda nada
        return "Aprobado" if self.promedio >= Estudiante.NOTA_APROBACION else "Reprobado"

    @staticmethod
    def validar_materia(texto):
        """Devuelve la materia normalizada o lanza ValueError."""
        materia = _normalizar_espacios(texto).title()
        if not materia:
            raise ValueError("La materia no puede estar vacía")
        if not Estudiante.es_materia_valida(materia):
            minimo, maximo = LIMITES["materia"]
            raise ValueError(
                f"La materia debe tener entre {minimo} y {maximo} caracteres, "
                f"incluir al menos una letra y no usar símbolos raros"
            )
        return materia

    @staticmethod
    def validar_nota(nota):
        """Devuelve la nota o lanza ValueError."""
        if not Estudiante.es_nota_valida(nota):
            raise ValueError(
                f"La nota debe ser un número entre {Estudiante.NOTA_MINIMA} y {Estudiante.NOTA_MAXIMA}"
            )
        return nota

    # ===== MÉTODOS DE INSTANCIA =====
    def inscribir_materia(self, materia):
        materia = Estudiante.validar_materia(materia)
        self.__materias.add(materia)        # add() no duplica
        return materia

    def agregar_nota(self, materia, nota):
        Estudiante.validar_nota(nota)
        materia = self.inscribir_materia(materia)      # valida la materia ANTES de guardar nada
        self.__notas.setdefault(materia, []).append(round(float(nota), 2))

    def notas_de(self, materia):
        return list(self.__notas.get(_normalizar_espacios(materia).title(), []))

    def materias_en_comun(self, otro):
        # INTERSECCIÓN de conjuntos
        return self.__materias & otro.materias

    def a_diccionario(self):
        return {
            "id": self.__id,
            "nombre": self.__nombre,
            "apellido": self.__apellido,
            "email": self.__email,
            "carnet": self.__carnet,
            "notas": self.__notas,
            "materias": sorted(self.__materias),   # JSON no guarda sets
        }

    def __str__(self):
        return f"[{self.__carnet}] {self.nombre_completo} - Promedio: {self.promedio} ({self.estado})"

    # ===== MÉTODO DE CLASE =====
    @classmethod
    def validar_campo(cls, campo, valor):
        """Valida UN campo sin crear el objeto completo. Lanza ValueError si está mal."""
        if campo not in cls.CAMPOS:
            raise ValueError(f"Campo no válido: {campo}")
        setattr(object.__new__(cls), campo, valor)

    @classmethod
    def desde_diccionario(cls, datos):
        return cls(
            datos["id"], datos["nombre"], datos["apellido"], datos["email"],
            datos["carnet"],
            notas=datos.get("notas", {}),
            materias=set(datos.get("materias", [])),   # lista -> conjunto otra vez
        )

    @classmethod
    def resumen(cls):
        return f"Se han creado {cls.total_creados} estudiantes en esta ejecución"
